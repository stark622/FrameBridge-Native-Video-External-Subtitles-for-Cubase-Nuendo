@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title FrameBridge — Native Video for Cubase ^& Nuendo - Rollback

set "SETUP=%~dp0_runtime\setup.ps1"
if not exist "%SETUP%" (
  echo [ERROR] _runtime\setup.ps1 is missing. Use UNINSTALL.cmd from the complete package.
  echo.
  pause
  exit /b 1
)

if "%~1"=="" (
  "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%SETUP%" -Action Uninstall
) else (
  "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%SETUP%" -Action Uninstall -ManualPath "%~1"
)
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo Rollback finished successfully.
) else if "%RC%"=="2" (
  echo Rollback cancelled. Nothing was changed.
) else (
  echo Rollback needs attention. Read the error above; unknown files were left untouched.
)
echo.
pause
exit /b %RC%
