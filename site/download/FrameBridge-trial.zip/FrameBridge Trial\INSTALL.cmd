@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title FrameBridge — Native Video for Cubase ^& Nuendo - Install

set "SETUP=%~dp0_runtime\setup.ps1"
if not exist "%SETUP%" (
  echo [ERROR] _runtime\setup.ps1 is missing. Re-download the complete package.
  echo.
  pause
  exit /b 1
)

if "%~1"=="" (
  "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%SETUP%" -Action Install
) else (
  "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%SETUP%" -Action Install -ManualPath "%~1"
)
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
  echo Installation finished successfully.
) else if "%RC%"=="2" (
  echo Installation cancelled. Nothing was changed.
) else (
  echo Installation was not completed. Read the error above; unsafe or unsupported files were left untouched.
)
echo.
pause
exit /b %RC%
