#!/usr/bin/env bash
# FFmpeg 9.0.2 for the DS reader v4: shared, LGPL 2.1+ only (no GPL / nonfree / version3), name suffix -dsr,
# D3D11VA/DXVA2 hwaccel, dav1d (BSD) for AV1, zlib; compiler runtimes linked statically (no libgcc/winpthread DLLs).
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
work="${FFMPEG_DSR_WORK:-$root/work}"
src="$work/ffmpeg-9.0.2"
build="$work/build"
prefix="$work/sdk"
mkdir -p "$work"
if [[ ! -x "$src/configure" ]]; then tar -xf "$root/ffmpeg-9.0.2.tar.xz" -C "$work"; fi
rm -rf "$build" "$prefix"; mkdir -p "$build" "$prefix"; cd "$build"
"$src/configure" --prefix="$prefix" --arch=x86_64 --target-os=mingw32 --cc=gcc --cxx=g++ \
  --enable-shared --disable-static --build-suffix=-dsr \
  --disable-programs --disable-doc --disable-debug --disable-avdevice --disable-avfilter \
  --disable-gpl --disable-nonfree --disable-version3 --disable-autodetect --disable-network \
  --disable-encoders --disable-muxers --disable-devices --disable-filters --disable-indevs --disable-outdevs \
  --enable-w32threads --disable-pthreads --enable-runtime-cpudetect \
  --enable-d3d11va --enable-dxva2 --enable-libdav1d --enable-zlib \
  --pkg-config-flags=--static --extra-ldflags="-static-libgcc -static" \
  --extra-version=dsr-lgpl21 2>&1 | tail -30
grep -E "^License|GPL|nonfree" ffbuild/config.log | head -3 || true
make -j16 > make.log 2>&1 || { tail -40 make.log; exit 1; }
make install > install.log 2>&1
echo FFMPEG_DSR_BUILD_OK
