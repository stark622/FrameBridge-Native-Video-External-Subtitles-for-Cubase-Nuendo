﻿[CmdletBinding()]
param(
    [ValidateSet('Install','Uninstall','Status')]
    [string]$Action = 'Install',
    [string]$ManualPath,
    [switch]$NoElevation,
    [string]$StateRootOverride,
    [switch]$SkipExtensionMappings
)

Set-StrictMode -Version 2.0
$script:InstallAlreadyCurrent = $false
$ErrorActionPreference = 'Stop'

$script:ProductName = 'FrameBridge — Native Video for Cubase & Nuendo'
$script:ProxyHash = 'C5E25DBC9C4D4345CC1C5B59D891F38E9300A32C6ADF7886667102CEE811BD5D'
$script:MxfProxyHash = 'D58228BC6B1BEEB36FC197CDA82507C5B08C7E53F0C08E7AAFD187929A63925F'
$script:KnownMxfProxyHashes = @(
    $script:MxfProxyHash,
    '4321525E4951E93B6A48C2815905E4FACC737597771F24F55F142EAE92042AC0'
)
# Steinberg Components\MXFHandler\mxfhandler.dll builds the MXF proxy is verified against:
# Cubase 10.5 / Nuendo 10, Cubase 11, Nuendo 12.0.52-15.0.30. Cubase 12+ ships without it.
$script:KnownMxfOriginals = @(
    'DA1ED3F729319B56F3D753561F98834544A676E19499FA0D110E5239C5503C62',
    'BF5BAEDC369675F83A29F3B0262B4856663F11E33E83AF30CCCB574409ABF7A3',
    '59B12C73BD6DCB71F53D9D4016CA190AE6A8DB09356BE8C14B2415D8B236C12A'
)
# Cubase 16: proxy for Components\avisupport.dll that hides Steinberg's AVI reader class, so .avi
# reaches FrameBridge. Installed only over a verified original; the original is kept in _dsreader.
$script:AviProxyHash = 'DC64AC1FE4D035E6E3A526B896C5FE105C0ADD8F3A2CC77BD65B20ADDF2F134B'
$script:KnownAviProxyHashes = @($script:AviProxyHash)
$script:KnownAviOriginals = @(
    '0C4B5154122DE2A768184DABD9810F7A79B67744FAAA24164F2CA326F6E0BA6D'
)
$script:ProbeHash = '605DA879AA10A19C900749FB444749E6502D56FE9A6808113A0F122A0DE067A5'
$script:KnownProxyHashes = @(
    $script:ProxyHash,
    '789856DB98ED5F56C192B8A276CE7DB0A7A8DF9F2F2751FAB6D3FF6D66AF7FE8', # prev demo build (40 s, strings in clear)
    'C401CE1BDBD31C2C0AD0B84F8925C2566418BB41538107E9E38E2806BD223981', # prev demo build (60 s per file)
    '900BD38D58B2E895AF0FA933854D5C5E3A71F1C08E3D9681FB7E9B0F6D20DC53', # prev demo build (TRIAL 0.18, one minute per process)
    'E5B38D7F4F782B7B4BC001241FD7C479013F93059C353F8D016E02FD06F5489E', # prev demo build ("Yamete kudasai!", TRIAL wordmark 0.10)
    '69B3B7FFD3A6516BA1DDB9DDA1B52936602FB950C23BE6ED5E6535AD0AD14454', # prev demo build (romaji "Yamete kudasai." period)
    '7F8B44326FF9AA25BB16D29FCCA1410D963FCCF0547597F437F42BDB97C834DF', # prev demo build (localized yamete, 26.11 am)
    '21564B7A622A73E5D267B87CD569D5BC5760DB1F76F94F261303EFE30FB3BA01', # prev demo build (Japanese-only yamete popup)
    '730B0822741D3335E6A8AC5BE528A2B1893D6C2BD92D2DF932D30D9E41320090', # beta 3 (paid) - demo may replace it
    '12B1E4B630B143E3CD1F47DC903309502DF1B6A8E783AA67340D14C89828CD7C',
    'DA549B2E21445FEB696E051ED1523210C1BDB8C711C5B508294A30BDF3370AF5',
    '619FB3E13471A88A10DFB27EC56937DAA524DF7A79CEB89B79EC0B6089D2BDEB',
    '2EA0CD4E5BC515B510E882CF50ED4FEC41678A25628363F956C1FD0D794DF461',
    '6F86574D3FE4F295EE07D6561A01398CC61EB7F9AE247B4E00E41011E0C1D89D', # Codex test builds 22-24.11 (кодекс тест)
    'F948FDCA52F9DEF396CB4E53429E7E2AFF3F5F9586D5B148212EDCDC48F5D210',
    '53CC560235430C90C85A941366A1F8AC4C47E4BB60D78502764BCD5E302B0700',
    '89F79C9AEC31EB47B426A0CEE77CDBF20B739F2EC3C45B3D03C19C90D1397CF8',
    '0B15BF18523F6C744FEA4125C6B60A329B2CD200A70E976D47F1B23235ACAEA8',
    '57563F29F8F0E90EE73F214B1E6F3B7A298F8FF27C61EA4CFDF1B3A3761B1D46',
    'ACFBD9ABA9B28226FDD4B1ABD72911E5A7395874DD04A805CACFF0952EECF0B5',
    'BD5E4E416842AD7F760FF7503AEA9A68A6EA4860002E703ECEC2337B23C31D04',
    '4A603E00F0816383A3B8966267808732F9320AF17C68FD647417901C88A3DBA5',
    'D8274E0D4ECAA7312B2DDF20E7DBF6C0CD99D79B57737E43529E4FBB1ABCD2F8',
    'B9B5A6DAD65CBF5807900430BB05D81A1652E9D42358CCFC01C5C50BDD8C23C5',
    '51832F9F4C68E7F10926E60A49EFB2C4807D3FA964030C15C82B9194E775BB8D',
    '7477301CB7DBCC0D772098369BDC8275ED39D5366CD6A96B9001BC226BF7D8ED',
    '4160C2EDA0A2173ACAE4FBDD63DF0189FB2AF3E819E46F90A5D46B639A74C837',
    'F9959B62A2271782D069279CE9B71BC25FAA11115D67C66D40FCEEE2CBFF80C7',
    '6AC131E241475A769F5663F2797E419C7CEE1047542BD82717326F20B9F15C07',
    '4F2D4D0D7ED6F5015056B1BFB2AB727DD0165413713382C3629CA8E5FCDA60C2',
    '0C66BA67C5326DD9BC09B23D56611857CB08A1506044870D17980B7EFD2D6FFF',
    'CF5BF204B4A99F06F96A50D393FA2384FF8A5E9626CF9BB9206957DF9EA2E64C',
    '258FEF9110316C8BDE7E36402C846F570DA0414A95ED6332771CA2C21382BE18',
    'AD9C6D0D4ED0EEDC5B058161F3DBB6C93807D392EE2A653DF2C9B283736DCC76',
    '0CA3FC7290EA0676812748A65B5C593356410F6B232B443F512ADC51151627C0',
    '516E296EBB9177E98339B91B32F7195AFC75270620BB32548673A386746E5F49',
    '5B656A89075FB6D20F75E5C870C1106D3E1C93C47FAC0041D398F63E2FBFC158',
    'BB9CDB4BA746DDCE744D8471F4C8560C38C7131CE818A6F94C28627F6BCB7E2A',
    'A3CF16C1B010760861F9DDDCC5B2A57AF3630B1BEA5248E614CC45ED37B272DB',
    '65FD2894C46C26A26B267761ED1F15D108994E3A91FBFCE4119925E8F71A5A96',
    '16202D495B80B2E81700C743A0CF485A3CD132905815FBE89F58579B815F581A',
    'D984DE7705494D82F6B3BA44926C019C1B9EA09118E593C5ABB8B64F3E26D828',
    '20ED911EFD45FA02986FCAD549427B72AF84A5FA57B5A5498233EF50401EB230',
    'AC5835A11CE17E2AC209244AFE3673B9EA13C65CA0F96E17008ECAA94A5B2218',
    'DAE03527C4DF52A1FB1743E1450F04D85D78BAC7B643FC310CEC32474074C8AD',
    '87DF8134D1B55CBA5A0EBF89376745A924A823C57028F16D0C49E2D5F49B6128',
    '9D2021007659AAFEF057ED012A46B2F45A224BC34D918B7423976C099EA5BC55',
    '13682F94F3DEF3EACF3FDB3407DC57055DC93446F9B9EB27E8F2266F2B0A2F46',
    '1329A676D7AB55B5090DFCF0BF3C75F89B2F7A6ED0CDC8D8CAA5498B53DE3740',
    '9C5C4AEBFCF418F51FDAD37AF6F124A03554B915C303264B253AE13EC5649ADC',
    '94DB7C938295DED52F0DAA1F6038DAAF4164145B40755E3FAF43ED4C1D6E6C60',
    '2DB73D759D81E0717A4325E0AF449F3F4516A4A85463BF8B5D2214AF34649201',
    '47A36A34B6BCE32B2C7CFFB0E59705E44869916222E8CEB8D86A2FF0D78CE545',
    '21E217C63671CC1CBDE46394FE08DC3169E95BAD32656C515DFF3EE85FFF3FE6',
    '56E7D8B72602156AEAB537A771BE6CD3B6A8D269000E175FD1AE9466C7512060',
    '80D2BABDF192320E80319266534D99DB761F1676EF5F4F270A3A39E0B19D1C27',
    '55D8D3095A5CE4F42C8E8A630A83F867B07ED143BDD52D3C4F72FC902DBAEA1F',
    '15FC50FB3FB9BD886B236CE97BD32FF979CFE29A876E10D5117FC9E8DE861FE5',
    '3DF676BD2EC1FC1A91406133A08E3C4DF27A5DA3360A6865F5153C5787F8512E',
    'F3725FB46F4F918DB6BB45994706AEE0D302AE680359C1BD74DEC81906EF31C3',
    '5CB8C026812D5D4D89FFDE1FFA4D8C3D63FF7045684E9B76EB37BEA6C95A76A2',
    '6D131BB01D92CFE681BE89C72308E7AE522AD991B6802399A4641E605F96D081',
    '24587EB558A79E6950FC66E2D22D25CB3611A021693F247D305AC51DD929458E',
    '6705178E8651469A1E4C22526D4D06CF29F390F745174719D9B4C6C86A8A9BA7',
    'C03D4085688DBE5951DAECAF18B43CB2CC9735EC602F9664A1198192BFE7B800',
    '20592B04F818B8BA4BE22F90CE96265CF44829AA26EF04E815916E71972FFB59',
    '4DE106F09C02BBBCCD89948582C73C9E49D188184665C4582814EC8A86CD7B88',
    'E721F6A09EA42E9E49FAA35ECF31AF49EDDB9173136EBF894FA25247DE38C840',
    'AE67FF2D4E594002425BDC5FE28334F5DC161E53C83C9E145818123411A6F33D',
    'B000AAC1B0ADB0C0F58D337103FCECDD4585C2CD28BA88C4F3C6F3076F643290',
    'C5E96050BD4D49597E46BA66E66C68AD5A7DC0A3BF389D95FAB93699D404E6EB',
    '089548623465E32D7FA1BCFD4A85A62CD4204FC0C78154D124142B10DAEADA18',
    '667D5BC753D43AE68F79967FAED62FDD706EA86F300B389BBA00AF9AAFAF6C03',
    'F971DE142436C3D3C240EB81574C670316DF4297865D688471A59F78C6A99DB6',
    '4E8FC0273BE00D426BECF86B45118C9985B60E411F95BDF0AF0BF4F2507E6F9A',
    'EB429D5C47E81917C93EBF7D05484DE1493BCEFE1BD2AEC63C0E5E6FA5836CF5',
    '630508C8206F2D7DB106B8FAC848721DAD247151930EE3453EF637AE1328A240',
    '2D9A5443D3ABDA085AAD2ED56BE3E56998FC152E17D81C2A8416674ADD2B48D0',
    'AD7E4242F66890C2F94A615E24A4019F9D931224E47CF83DD4E799558AE580F6',
    'CE0178BE19AB4D7465519C6BEB07C3DB0B008A683E429DAD1A28B94C8B10B80D',
    '1D284B94B58265F78CF44392ABFC9EFB158267009BCC9A07966B2A92195E3325',
    '41E05F0BFB41AA6C9BB09202AE11010C04D871EDEC5C365E308EAFF2FF7CD6C1',
    'BC17FBA08548B5AF85B0FA406D881077161414FD56FE7D500911DB13D786701B',
    'A5BEAAA9059E4DB59986DB78CE43FD0D63A108C34BEC65839A70997D29D653A2',
    '7A9B03DE4FDF1363098EFD246FD53CCC9C3DA89DB90955775B4CFA52FDAF1CD7',
    'BA68266FA43BB99042C53967C164534434AFB8E062CD0BA9D9925932F11B6A44',
    '5EC16DBCF0CBBF3A15B8E8D34A964837671DEF5E0DB6504BE2851E51C46507DE',
    '5C4A802D4033DE4293598B496D8B921ADDB046FF39709BEC623AF1F19507596B',
    '6C0337CAB250C6C4F9DE2B21296CD3E64E6B5231848E5292501543CB4FE61B51',
    '2778B28B952E01FE29A4B6D3C6855A113D7558BD896DEED48CE8FEAEA3AA53AA',
    '6A23308C272685A0C2E3D78173FEBE6A2D4AF715F6208760228D8F1CC9B686E1',
    '4AFD933CDD005FBEDCAC35D481631630AC3F2E3588311E30611CD5C56601C5BA',
    '7628DB3CEA345772223D40D83B278CEC9A2D389949D742A91F39EC9B7E25556B',
    'C46EA75712033DA4FBF542257C753150375C02BE19EBD2FEA8990A6FF524C21C',
    'A7B8E6F1B830BF498330D7A7C2097371F3C30EBCDB79D002DFFD216AA86E1FA3',
    'EC006FF2344450C861A02D1BA61C877DA60AF6C13D3CEC4A0A9438D02AC507D3',
    '25CE5F9910FF4DFB1706583CBB9D4A6649B1748F2056545162FD4D09AF83C679',
    'A0A8120F9AFE4415692BD80CAADAA94133370F93833EE2E67905AD36A3331D13',
    'B80C47EF1E66A808CC7BE61DD346346545072EB3C9A4DE317AA4F8AA668DA077',
    '42FE19A2EEB4043BF57308FFD92E48A357B2A92B2DA88FDEC6D964681C6B5673',
    '78BF61D0D3F527B766942D40D94CC35A62CE7B1E13102410D28BCEFE8D322A31',
    '0A377E0222F33E447CBFDAA4F000DAF066BBA3C491B7879FF542165DD67878DC',
    '0172AAA979E65A29F076CB4AA0B51CA110D22E423C45208EA1424B15C8F9C21C',
    '5346070478EF5905DAF04CEA94B2073B29E288F22D601FC4B10672731437463F',
    'B5023E060CD47C6085A128E919C08170A35403527A03CE0AF635084D790BFC5A',
    'B6C5B5EDCCD999E83A1978A99F03D7C0267E2AB96E6E530EBB83C18A80A702AD',
    '2AC83FCA94524EE99EF8154245140E0A48F8DA1C90CB9011C2455DA8567FE9B0',
    'DBBA4C0202E2DC3BACF458D3C9DD6F8501C161040F3B4B4A6C016197F61E5DE9',
    'E6188B8D33CE5672E2BA43B3E5419CC8525F75C60638C5DEA20448956134B84D',
    '14055D8B6AC37D099F85F5B56EF55D66F7CFB741D1BB0ABDD6BC4EE46E67A5D8',
    '8A18E96835BC7650F6F55F046F659998EB1B9AB6FDF840C0E2FC25FABB759977',
    '40970B0DEF39E215630BCF154A3E7B91A7B31ABA2E457A94AE6579CB8A345A50',
    '6FD746C6D3E60B9651AFA9E3104F06AD9D8187E72436067E928897EE37E57305',
    '5FDFDF8D1E75B97FAD88FF4A57DCB2DE5BDABD4CEFEC7A06287F92F67FC56E2F',
    '7C7310E08783B380711DC1B10584A359998002076B4FE1EF8C1133E1DA81B080',
    '7790D6814F1DB7DFCCB34722720C5AFDE5006E9F28341A2F988898BA18DB39D7',
    '6E783938A3B78DB1AF5FC66A3923CF90745241436B1375AFC18698F6658F38F8',
    'FB2A24DCBF7A57B04BAAFBD3A92C03D81028AFF655813E175FC021ADBCD1FE2B',
    '853A0E4BD4462FE1CB900E726F28C7E17287FAF485B4F9F08ED3F339AF299BAF',
    'E8F3B3537D6C65D87AEC1A7CE2D3462C8318DF4CFBA9F1CF4B022815ADEB1DB3',
    '356C31AED2555692CA5EAA5EC18E42937EEEFFD61A5A6F7EB318A3F9A808EC50',
    '82118FB1B8145D8510A32C1E1AB3F72620005079A996E5D6925257E6FD19EE4C',
    '66731E138D92A570633E0658AAEBF2BEE5522E19D0DE64E4B53067FE6A551A61',
    '9B5CF68184B86BDE35C84345B25BC32D7CAAF839870C927BEB92E257B8A9B2E4',
    'DFD8C5DE56D459E316622BE2930DD7F26644507B019C53CA4ED3F5FEBDC69B2B',
    '6831AE34F104BBB5FF3C61D0EDF7B35AF93272B9DB4854BA025CC582A53CAE9F',
    '4092A10322BF30293170AF594DBAABC73F4006AA005A03E4F8FD7C3349650D28',
    'EFCF8255F2B966544A1338E5BB06F0EC7CD37E5621A9AFBB97CD3A3FEB155691',
    '460DAF8F05502490156DFEDD5DB0545E8180A6454786888A9917BBE83558B3FB',
    'CD8ED38291A7664305AFFE4EBEFC646D7493EA4243EB8BECB300954E67EF27AB',
    'A9EFB842C1DC110995480EC4AD358E8557D0E68B2F39E11134743C6A6AE4ED66',
    'B0E9F7BD5AB7576A7069D2AB70A83B668C7009602BF1328B6AFAB93C44673446',
    '33DA16D8AB673280537100103740490068F5262C50F8997F2C17EC9AF6B07F23',
    '0D4E57AA76568D657394280F199609E5760B52DCC1164AB68A6F409229B2B497',
    '9B3FE3CB472D156050352085E362118620BD6702932392C612010E64EE710C15'
)


$script:HostExePattern = '^(Cubase|Nuendo)(?:\d+(?:\.\d+)*|(?:[ ._-]+[A-Za-z0-9]+)+)?\.exe$'


# Exact originals require full SHA-256 plus PE identity and the control vtable value.
# VerifyRva points at a stable vtable slot; VerifyValue is the exact 64-bit value stored there.
$script:Profiles = @(
    [pscustomobject]@{ Id='v3-10'; Hash='3DAAD4CAA9F2D621B49DB4D6E0F96327627D3F05A887899DD8A6A64912EC90D6'; Stamp=[uint32]0x5D145F39; Image=[uint32]0x00FCE000; VerifyRva=[uint32]0x00AD3A70; VerifyValue=[uint64]0x000000018034E910 },
    [pscustomobject]@{ Id='v3-11'; Hash='CD7C3514CC3A57BCCFD79FA0A24149C70164B2BFAC520253F825906DD87A4296'; Stamp=[uint32]0x5FD32AB6; Image=[uint32]0x00F3E000; VerifyRva=[uint32]0x00ADE1F0; VerifyValue=[uint64]0x0000000180351A80 },
    [pscustomobject]@{ Id='v4-12.0'; Hash='589A97AB01A3A111389928BFAB94E02C0432080E0AB1B17D665C9828826B4685'; Stamp=[uint32]0x6218A297; Image=[uint32]0x00B0C000; VerifyRva=[uint32]0x0088EF88; VerifyValue=[uint64]0x000000018038B870 },
    [pscustomobject]@{ Id='v4-12.1'; Hash='EB9E04C0459C0A36484D76F1100EED40C518C66CBAC7780CA66832AC1E52A2EB'; Stamp=[uint32]0x6322F556; Image=[uint32]0x00B09000; VerifyRva=[uint32]0x00888D58; VerifyValue=[uint64]0x0000000180382720 },
    [pscustomobject]@{ Id='v4-13.50'; Hash='C267B6B1B187B4B51B2758EB4220487D074F8351D524E277460013BE15A90254'; Stamp=[uint32]0x67125B19; Image=[uint32]0x00949000; VerifyRva=[uint32]0x00742440; VerifyValue=[uint64]0x0000000180366910 },
    [pscustomobject]@{ Id='v4-13.10'; Hash='24387927EEDA51019B7BBAB0E1C78B552BD5E2CFA99CA0A824FE0423BFB7A9BB'; Stamp=[uint32]0x651FD1F3; Image=[uint32]0x0094A000; VerifyRva=[uint32]0x00743480; VerifyValue=[uint64]0x00000001803668F0 },
    [pscustomobject]@{ Id='v5-14.05'; Hash='A631D022B8D6CF88D84B46BAD8594B0D847C776B4159E3FDA496F9C0F742A132'; Stamp=[uint32]0x66FA9936; Image=[uint32]0x005C4000; VerifyRva=[uint32]0x00411E60; VerifyValue=[uint64]0x0000000180073D30 },
    [pscustomobject]@{ Id='v5-14.10'; Hash='1804A1F376E74327445118B9D50C35D5CD5EFF91397837058DDBFCC15AA2891C'; Stamp=[uint32]0x67483E66; Image=[uint32]0x00539000; VerifyRva=[uint32]0x0039EEB8; VerifyValue=[uint64]0x000000018006A3C0 },
    [pscustomobject]@{ Id='v5-14.20'; Hash='63BB502F0D7CF92379B7AD7B1BD9FA9391613DE7A43425009A018BD13008D3FA'; Stamp=[uint32]0x67B34B27; Image=[uint32]0x0053D000; VerifyRva=[uint32]0x003A2028; VerifyValue=[uint64]0x000000018006A980 },
    [pscustomobject]@{ Id='v5-14.30'; Hash='19AC4C34C6A7F4963F244CAFED3FFCFAC02454C9E9B8E653C8FFC5F4C782798F'; Stamp=[uint32]0x68224B52; Image=[uint32]0x00547000; VerifyRva=[uint32]0x003A9188; VerifyValue=[uint64]0x000000018006AF40 },
    [pscustomobject]@{ Id='v5-14.40'; Hash='1651312B173A4CC5BEEFB28A4BAFFF88D3DC0896F0AC4EE9C761E6A3719C816F'; Stamp=[uint32]0x68E3C26C; Image=[uint32]0x00548000; VerifyRva=[uint32]0x003AA1A8; VerifyValue=[uint64]0x000000018006B020 },
    [pscustomobject]@{ Id='v5.1-15.05'; Hash='175255E18FA7ECA3997360B061405EF2BFB8F46DBE83031CD158D676B62136E6'; Stamp=[uint32]0x68E4FCD9; Image=[uint32]0x00548000; VerifyRva=[uint32]0x003AC5A0; VerifyValue=[uint64]0x000000018006C4A0 },
    [pscustomobject]@{ Id='v5.1-C15.21'; Hash='78F7DCAAAD36FEBE872C234B47322FBCF8A4AAE30B834D381F7004ED8F9F1FD5'; Stamp=[uint32]0x69D8EFF2; Image=[uint32]0x00569000; VerifyRva=[uint32]0x003CA3B8; VerifyValue=[uint64]0x0000000180061970 },
    [pscustomobject]@{ Id='v5.1-C15.30'; Hash='3028D947796DE6F63AF4A58270A1801FC33B71981306F946BBFDDFC311E465A0'; Stamp=[uint32]0x69FDC04F; Image=[uint32]0x00569000; VerifyRva=[uint32]0x003CA3B8; VerifyValue=[uint64]0x00000001800619D0 },
    [pscustomobject]@{ Id='v5.1-N15.21'; Hash='DA94C825CB4062B1B3987F3D14EB32E9CFBB5918E63CCCAA1216D61C5B1501DC'; Stamp=[uint32]0x69D8EFA5; Image=[uint32]0x00752000; VerifyRva=[uint32]0x00573930; VerifyValue=[uint64]0x000000018007A080 },
    [pscustomobject]@{ Id='v5.1-N15.30'; Hash='9E4587B1136608A0CF7F00E99916DBFC66E153B74FB403DEB9A2173390493DF6'; Stamp=[uint32]0x69FDC82E; Image=[uint32]0x00753000; VerifyRva=[uint32]0x00574930; VerifyValue=[uint64]0x000000018007A0E0 },
    [pscustomobject]@{ Id='v5.1-N15.40'; Hash='46497215F4A34FE5CD15EEE729D5AB6282C518BA2D112C5946DDD55043D5DE1B'; Stamp=[uint32]0x6ABA8F7B; Image=[uint32]0x004A4000; VerifyRva=[uint32]0x00352680; VerifyValue=[uint64]0x00000001800554F0 },
    [pscustomobject]@{ Id='c16-16.0.5'; Hash='99079D373516D337B0F7F409B06D4B4690729BDFFDDCDEF7349AB222C12C8A41'; Stamp=[uint32]0x6ABA8FBF; Image=[uint32]0x00323000; VerifyRva=[uint32]0x00245E98; VerifyValue=[uint64]0x4D0A0841FA52512F },
    [pscustomobject]@{ Id='legacy-C8.0.10'; Hash='0A3E2D69C249E0EB5756A0AA65CBD9CA0E6768789AFCC784435D56C7AAEAFF18'; Stamp=[uint32]0x544566C2; Image=[uint32]0x00387000; VerifyRva=[uint32]0x002846B8; VerifyValue=[uint64]0x0000000180141820 },
    [pscustomobject]@{ Id='legacy-C9.0.0'; Hash='A1A931A07D26D426324D9042427716B852395701E5664B3316B2B159FE3B7E5E'; Stamp=[uint32]0x57E0F98B; Image=[uint32]0x00388000; VerifyRva=[uint32]0x002837C0; VerifyValue=[uint64]0x0000000180141340 }
)

$script:LavSource = '{B98D13E7-55DB-4385-A33D-09FD1BA26338}' # only to remove mappings v2 added
# v3: own FFmpeg runtime (LGPL 2.1, shared, *-dsr-* names) installed to <host>\_dsreader\ffmpeg.
$script:FfmpegFiles = [ordered]@{
    'avutil-dsr-61.dll' = '1423AF10FE5F8E5B164FB55BDED077F1C53196F258899500C9B624E0967FD31A'
    'swresample-dsr-7.dll' = '4FF24AA0A6B261BE07C69BCD72322F73868CAA2136978C2B0AE84D962DA1489F'
    'swscale-dsr-10.dll' = '4BAFD2917BC059928B66E7D478807659F639FADB26A7109E6860A4F61D8A23F2'
    'avcodec-dsr-63.dll' = '0FD428B8D5144CB53639C57D6304290DA966A783E15D97A386AB461A5CAD1C16'
    'avformat-dsr-63.dll' = '0D07E4E89F514A48E6CD8117535A51B029A2F0A93A0CD5C32F312927F70417C3'
}
# Exact payload hashes owned by released installers. Add older released hashes
# here per filename; unknown/user-replaced DLLs must survive rollback.
$script:KnownFfmpegHashes = [ordered]@{
    'avutil-dsr-61.dll' = @('1423AF10FE5F8E5B164FB55BDED077F1C53196F258899500C9B624E0967FD31A','5EDCA375C17B9F44FCBA64474293250ED3154019309DA0B7674D7006855335BC')
    'swresample-dsr-7.dll' = @('4FF24AA0A6B261BE07C69BCD72322F73868CAA2136978C2B0AE84D962DA1489F','A89284D7E114A1A91067596A35FF5F5B420B8B6F44A0EBC2EE3F1A25D3AC58D3')
    'swscale-dsr-10.dll' = @('4BAFD2917BC059928B66E7D478807659F639FADB26A7109E6860A4F61D8A23F2','1DDDE4E45071C42FBE1B5A96C3D36EC3AFB935A276FE1391D446F374FAC01CF3')
    'avcodec-dsr-63.dll' = @('0FD428B8D5144CB53639C57D6304290DA966A783E15D97A386AB461A5CAD1C16','4C7B96F35610F4D6B958C32B8D98934A847ADD6935AC60C8E15C09DEAB0821A9')
    'avformat-dsr-63.dll' = @('0D07E4E89F514A48E6CD8117535A51B029A2F0A93A0CD5C32F312927F70417C3','DF3D4A7CD5E31D4BB3E452269B4FA2634FF3A134B8507CEF6F19FAADF2FDCD0F')
}
$script:Extensions = @('mkv','mk3d','webm','flv','f4v','ts','m2ts','mts','m2t','vob','evo','ogv','ogm','3gp','3g2','m4v','mp4','mov','avi','wmv','asf','rmvb','rm','divx','mxf','mpg','mpeg')

function Write-Info([string]$Text) { Write-Host ('[INFO] ' + $Text) -ForegroundColor Cyan }
function Write-Ok([string]$Text) { Write-Host ('[OK]   ' + $Text) -ForegroundColor Green }
function Write-Warn([string]$Text) { Write-Host ('[WARN] ' + $Text) -ForegroundColor Yellow }
function Write-Fail([string]$Text) { Write-Host ('[ERROR] ' + $Text) -ForegroundColor Red }

function Get-FileSha256([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function Read-U16([byte[]]$Bytes, [int]$Offset) { return [BitConverter]::ToUInt16($Bytes, $Offset) }
function Read-U32([byte[]]$Bytes, [int]$Offset) { return [BitConverter]::ToUInt32($Bytes, $Offset) }
function Read-U64([byte[]]$Bytes, [int]$Offset) { return [BitConverter]::ToUInt64($Bytes, $Offset) }

function Convert-RvaToOffset([byte[]]$Bytes, [int]$PeOffset, [uint32]$Rva) {
    $sectionCount = Read-U16 $Bytes ($PeOffset + 6)
    $optionalSize = Read-U16 $Bytes ($PeOffset + 20)
    $sectionOffset = $PeOffset + 24 + $optionalSize
    for ($i = 0; $i -lt $sectionCount; $i++) {
        $s = $sectionOffset + (40 * $i)
        $virtualSize = Read-U32 $Bytes ($s + 8)
        $virtualAddress = Read-U32 $Bytes ($s + 12)
        $rawSize = Read-U32 $Bytes ($s + 16)
        $rawPointer = Read-U32 $Bytes ($s + 20)
        $span = [Math]::Max([uint64]$virtualSize, [uint64]$rawSize)
        if (([uint64]$Rva -ge [uint64]$virtualAddress) -and ([uint64]$Rva -lt ([uint64]$virtualAddress + $span))) {
            $offset = [uint64]$rawPointer + ([uint64]$Rva - [uint64]$virtualAddress)
            if (($offset + 8) -gt $Bytes.LongLength) { return -1 }
            return [int64]$offset
        }
    }
    return -1
}

function Get-ExactEngineProfile([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    try {
        [byte[]]$bytes = [IO.File]::ReadAllBytes($Path)
        if ($bytes.Length -lt 512 -or (Read-U16 $bytes 0) -ne 0x5A4D) { return $null }
        $pe = [int](Read-U32 $bytes 0x3C)
        if ($pe -lt 64 -or ($pe + 256) -gt $bytes.Length -or (Read-U32 $bytes $pe) -ne 0x00004550) { return $null }
        $stamp = Read-U32 $bytes ($pe + 8)
        $image = Read-U32 $bytes ($pe + 0x50)
        $hash = Get-FileSha256 $Path
        foreach ($profile in $script:Profiles) {
            if ($profile.Hash -ne $hash -or $profile.Stamp -ne $stamp -or $profile.Image -ne $image) { continue }
            $fileOffset = Convert-RvaToOffset $bytes $pe $profile.VerifyRva
            if ($fileOffset -lt 0) { continue }
            if ((Read-U64 $bytes ([int]$fileOffset)) -eq $profile.VerifyValue) { return $profile }
        }
    } catch { return $null }
    return $null
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Quote-Argument([string]$Value) {
    if ($null -eq $Value) { return '""' }
    return '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

function Test-HostExeName([string]$Name) {
    return [bool]($Name -match $script:HostExePattern)
}

function Get-HostFamily([string]$HostExeName) {
    if (-not (Test-HostExeName $HostExeName)) { return $null }
    if ($HostExeName -match '^(?i:Cubase)') { return 'Cubase' }
    if ($HostExeName -match '^(?i:Nuendo)') { return 'Nuendo' }
    return $null
}

function Get-CompatibleEngine([string]$Path, [string]$HostExeName) {
    $exact = Get-ExactEngineProfile $Path
    if ($exact) {
        return [pscustomobject]@{ Id=$exact.Id; Mode='EXACT'; Description=$exact.Id }
    }
    $family = Get-HostFamily $HostExeName
    if (-not $family -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    if (-not $script:ProbePath -or -not (Test-Path -LiteralPath $script:ProbePath -PathType Leaf)) { return $null }
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $script:ProbePath
    $start.Arguments = (Quote-Argument $Path) + ' ' + (Quote-Argument $family) + ' --abi-only'
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = [Diagnostics.Process]::Start($start)
    try {
        if (-not $process.WaitForExit(15000)) {
            try { $process.Kill() } catch { }
            return $null
        }
        $output = $process.StandardOutput.ReadToEnd().Trim()
        if ($process.ExitCode -ne 0 -or $output -notmatch '^COMPATIBLE\|ABI\|') { return $null }
        $parts = $output -split '\|'
        if ($parts.Count -lt 5) { return $null }
        $id = 'abi-{0}-{1}-{2}' -f $family.ToLowerInvariant(),$parts[3],$parts[4]
        return [pscustomobject]@{ Id=$id; Mode='ABI'; Description=$parts[2] }
    } finally {
        $process.Dispose()
    }
}

function Invoke-ElevatedSelf {
    $parts = @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Quote-Argument $PSCommandPath),'-Action',$Action)
    if ($ManualPath) { $parts += @('-ManualPath',(Quote-Argument $ManualPath)) }
    if ($StateRootOverride) { $parts += @('-StateRootOverride',(Quote-Argument $StateRootOverride)) }
    if ($SkipExtensionMappings) { $parts += '-SkipExtensionMappings' }
    $process = Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList ($parts -join ' ') -Verb RunAs -Wait -PassThru
    exit $process.ExitCode
}

function Get-StateRoot {
    if ($StateRootOverride) { return [IO.Path]::GetFullPath($StateRootOverride) }
    return (Join-Path $env:ProgramData 'CubaseNuendoDirectShow')
}

function New-EmptyState {
    return [pscustomobject]@{ Schema=3; Product=$script:ProductName; Installs=@(); AddedExtensions=@() }
}

function Load-State([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return (New-EmptyState) }
    try {
        $state = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not ($state.PSObject.Properties.Name -contains 'Installs')) { $state | Add-Member -NotePropertyName Installs -NotePropertyValue @() }
        if (-not ($state.PSObject.Properties.Name -contains 'AddedExtensions')) { $state | Add-Member -NotePropertyName AddedExtensions -NotePropertyValue @() }
        return $state
    } catch {
        throw "State file is damaged: $Path"
    }
}

function Save-State($State, [string]$StateRoot, [string]$StatePath) {
    if (-not (Test-Path -LiteralPath $StateRoot -PathType Container)) { New-Item -ItemType Directory -Path $StateRoot -Force | Out-Null }
    $temp = $StatePath + '.new'
    $previous = $StatePath + '.old'
    try {
        $State | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $temp -Encoding UTF8
        $stream = [IO.File]::Open($temp,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::Read)
        try { $stream.Flush($true) } finally { $stream.Dispose() }
        $null = Get-Content -LiteralPath $temp -Raw -Encoding UTF8 | ConvertFrom-Json
        if (Test-Path -LiteralPath $StatePath -PathType Leaf) {
            if (Test-Path -LiteralPath $previous -PathType Leaf) { Remove-Item -LiteralPath $previous -Force }
            [IO.File]::Replace($temp,$StatePath,$previous,$true)
        } else {
            Move-Item -LiteralPath $temp -Destination $StatePath
        }
    } finally {
        if (Test-Path -LiteralPath $temp -PathType Leaf) { Remove-Item -LiteralPath $temp -Force }
        if (Test-Path -LiteralPath $previous -PathType Leaf) { Remove-Item -LiteralPath $previous -Force }
    }
}

function Test-FfmpegPayload {
    foreach ($name in $script:FfmpegFiles.Keys) {
        if ((Get-FileSha256 (Join-Path $script:PackageFfmpeg $name)) -ne $script:FfmpegFiles[$name]) {
            throw ("The packaged decoder runtime _runtime\ffmpeg\{0} is missing or damaged." -f $name)
        }
    }
    Write-Ok 'Built-in decoder (FFmpeg, LGPL 2.1) verified. No codec pack or LAV Filters needed.'
}

function Get-FfmpegDir($HostRecord) { return (Join-Path $HostRecord.HostPath '_dsreader\ffmpeg') }
function Test-FfmpegCurrent($HostRecord) {
    $dir = Get-FfmpegDir $HostRecord
    foreach ($name in $script:FfmpegFiles.Keys) {
        if ((Get-FileSha256 (Join-Path $dir $name)) -ne $script:FfmpegFiles[$name]) { return $false }
    }
    return $true
}

# Cubase 8 / 9.0 engines start their 32-bit QuickTime helper processes from the folder the engine DLL
# is loaded from. The original engine runs from _dsreader, so exact copies of the helpers are placed
# there (without them: "QuickTime cannot be initialized" and no video at all) and removed on rollback.
# Hosts without these files in Components (10-15) are not affected.
$script:LegacyHelpers = @('videodecode.exe','videooutput.exe','videopreload.exe')
function Install-LegacyHelpers($HostRecord) {
    $components = Split-Path -Parent $HostRecord.EnginePath
    $target = Split-Path -Parent $HostRecord.BackupPath
    foreach ($name in $script:LegacyHelpers) {
        $src = Join-Path $components $name
        if (-not (Test-Path -LiteralPath $src -PathType Leaf)) { continue }
        $dst = Join-Path $target $name
        $hash = Get-FileSha256 $src
        if ((Get-FileSha256 $dst) -eq $hash) { continue }
        Copy-Item -LiteralPath $src -Destination $dst -Force
        if ((Get-FileSha256 $dst) -ne $hash) { throw ("Video helper copy verification failed: {0}" -f $dst) }
    }
}
function Uninstall-LegacyHelpers($HostRecord) {
    $components = Split-Path -Parent $HostRecord.EnginePath
    $target = Split-Path -Parent $HostRecord.BackupPath
    foreach ($name in $script:LegacyHelpers) {
        $dst = Join-Path $target $name
        if (-not (Test-Path -LiteralPath $dst -PathType Leaf)) { continue }
        $src = Join-Path $components $name
        if ((Get-FileSha256 $src) -eq (Get-FileSha256 $dst)) { Remove-Item -LiteralPath $dst -Force }
        else { Write-Warn ("Preserved unknown file during rollback: {0}" -f $dst) }
    }
}

function Assert-FfmpegInstallSafe($HostRecord) {
    $dir = Get-FfmpegDir $HostRecord
    if (-not (Test-Path -LiteralPath $dir -PathType Container)) { return }
    foreach ($file in @(Get-ChildItem -LiteralPath $dir -File -Filter '*.dll' -ErrorAction SilentlyContinue)) {
        if (-not $script:KnownFfmpegHashes.Contains($file.Name)) {
            throw ("Unknown FFmpeg DLL found; installation refused without changing it: {0}" -f $file.FullName)
        }
        $hash = Get-FileSha256 $file.FullName
        if ($script:KnownFfmpegHashes[$file.Name] -notcontains $hash) {
            throw ("Unknown SHA-256 for FFmpeg DLL; installation refused without changing it: {0} [{1}]" -f $file.FullName,$hash)
        }
    }
}

function Install-Ffmpeg($HostRecord) {
    Assert-FfmpegInstallSafe $HostRecord
    $dir = Get-FfmpegDir $HostRecord
    if (-not (Test-Path -LiteralPath $dir -PathType Container)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    foreach ($name in $script:FfmpegFiles.Keys) {
        $dst = Join-Path $dir $name
        if ((Get-FileSha256 $dst) -eq $script:FfmpegFiles[$name]) { continue }
        Install-Atomically (Join-Path $script:PackageFfmpeg $name) $dst $script:FfmpegFiles[$name]
    }
}

# Removes only exact files and hashes owned by released installers. A compatible
# user replacement, even under the same filename, is deliberately preserved.
function Uninstall-Ffmpeg($HostRecord) {
    $dir = Get-FfmpegDir $HostRecord
    if (-not (Test-Path -LiteralPath $dir -PathType Container)) { return }
    foreach ($name in $script:KnownFfmpegHashes.Keys) {
        $path = Join-Path $dir $name
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        $hash = Get-FileSha256 $path
        if ($script:KnownFfmpegHashes[$name] -contains $hash) {
            Remove-Item -LiteralPath $path -Force
        } else {
            Write-Warn ("Preserved unknown/user FFmpeg DLL during rollback: {0}" -f $path)
        }
    }
    if (-not (Get-ChildItem -LiteralPath $dir -Force | Select-Object -First 1)) { Remove-Item -LiteralPath $dir -Force }
}

function Get-HostRecordFromExe([string]$ExePath) {
    if (-not (Test-Path -LiteralPath $ExePath -PathType Leaf)) { return $null }
    $name = [IO.Path]::GetFileName($ExePath)
    if (-not (Test-HostExeName $name)) { return $null }
    $family = Get-HostFamily $name
    try {
        $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($ExePath)
        $company = ([string]$version.CompanyName).Trim()
        $product = ([string]$version.ProductName).Trim()
        $description = ([string]$version.FileDescription).Trim()
        $identityPattern = '^(?i:' + [Regex]::Escape($family) + ')(?:\b|$)'
        if ($company -notmatch '^(?i:Steinberg Media Technologies)\b') { return $null }
        if ($product -notmatch $identityPattern -and $description -notmatch $identityPattern) { return $null }
    } catch { return $null }
    $root = Split-Path -Parent $ExePath
    $engine = Join-Path $root 'Components\videoengine.dll'
    if (-not (Test-Path -LiteralPath $engine -PathType Leaf)) { return $null }
    return [pscustomobject]@{ HostPath=[IO.Path]::GetFullPath($root).TrimEnd('\'); HostExe=$name; EnginePath=$engine; BackupPath=(Join-Path $root '_dsreader\videoengine_orig.dll') }
}

function Add-HostRecord([Collections.Generic.List[object]]$List, $Record) {
    if ($null -eq $Record) { return }
    foreach ($existing in $List) { if ($existing.HostPath -ieq $Record.HostPath) { return } }
    $List.Add($Record)
}

function Find-HostsAtExplicitPath([string]$Path, [Collections.Generic.List[object]]$List) {
    if (-not $Path) { return }
    $full = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($Path))
    if (-not (Test-Path -LiteralPath $full)) { return }
    $item = Get-Item -LiteralPath $full -ErrorAction SilentlyContinue
    if ($item -and -not $item.PSIsContainer) {
        Add-HostRecord $List (Get-HostRecordFromExe $item.FullName)
        return
    }
    # An explicitly selected installation folder is inspected only at its top level.
    Get-ChildItem -LiteralPath $full -File -ErrorAction SilentlyContinue |
        Where-Object { Test-HostExeName $_.Name } |
        ForEach-Object { Add-HostRecord $List (Get-HostRecordFromExe $_.FullName) }
}

function Get-DisplayIconExe([string]$Value) {
    if (-not $Value) { return $null }
    $expanded = [Environment]::ExpandEnvironmentVariables($Value).Trim()
    if ($expanded -match '^"([^"]+\.exe)"') { return $matches[1] }
    $candidate = ($expanded -split ',')[0].Trim().Trim('"')
    if ($candidate -match '(?i)\.exe$') { return $candidate }
    return $null
}

function Discover-Hosts($State, [string]$ForAction) {
    $list = New-Object 'Collections.Generic.List[object]'

    # Automatic discovery is registry-only. No Program Files/Desktop/full-disk recursion.
    foreach ($view in @('Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths','Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths')) {
        Get-ChildItem -LiteralPath $view -ErrorAction SilentlyContinue |
            Where-Object { Test-HostExeName $_.PSChildName } |
            ForEach-Object {
                try {
                    $key = Get-Item -LiteralPath $_.PSPath -ErrorAction Stop
                    $target = [Environment]::ExpandEnvironmentVariables([string]$key.GetValue(''))
                    if (-not $target) {
                        $registeredPath = [Environment]::ExpandEnvironmentVariables([string]$key.GetValue('Path'))
                        if ($registeredPath) {
                            if (Test-Path -LiteralPath $registeredPath -PathType Leaf) { $target = $registeredPath }
                            else { $target = Join-Path $registeredPath $_.PSChildName }
                        }
                    }
                    if ($target) { Add-HostRecord $list (Get-HostRecordFromExe $target) }
                } catch { }
            }
    }

    foreach ($uninstallRoot in @(
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
        'Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
    )) {
        Get-ChildItem -LiteralPath $uninstallRoot -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $p = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction Stop
                if ([string]$p.DisplayName -match '(?i)\b(Cubase|Nuendo)\b') {
                    $iconExe = Get-DisplayIconExe ([string]$p.DisplayIcon)
                    if ($iconExe) { Add-HostRecord $list (Get-HostRecordFromExe $iconExe) }
                    if ($p.InstallLocation) { Find-HostsAtExplicitPath ([string]$p.InstallLocation) $list }
                }
            } catch { }
        }
    }

    # Product state is used automatically only for rollback/status, never to discover
    # an unregistered test copy for a new installation.
    if ($ForAction -ne 'Install') {
        foreach ($record in @($State.Installs)) {
            if (-not $record.HostPath -or -not $record.HostExe) { continue }
            try { Add-HostRecord $list (Get-HostRecordFromExe (Join-Path ([string]$record.HostPath) ([string]$record.HostExe))) } catch { }
        }
    }

    $array = New-Object object[] $list.Count
    $list.CopyTo($array)
    return $array
}

function Get-ExplicitHosts([string]$Path) {
    $list = New-Object 'Collections.Generic.List[object]'
    Find-HostsAtExplicitPath $Path $list
    $array = New-Object object[] $list.Count
    $list.CopyTo($array)
    return $array
}

function Get-HostDisplayName($HostRecord) {
    $exePath = Join-Path $HostRecord.HostPath $HostRecord.HostExe
    try {
        $v = [Diagnostics.FileVersionInfo]::GetVersionInfo($exePath)
        $name = if ($v.FileDescription) { $v.FileDescription.Trim() } elseif ($v.ProductName) { $v.ProductName.Trim() } else { [IO.Path]::GetFileNameWithoutExtension($HostRecord.HostExe) }
        $version = if ($v.ProductVersion) { $v.ProductVersion.Trim() } elseif ($v.FileVersion) { $v.FileVersion.Trim() } else { '' }
        if ($version) { return ("{0} {1}" -f $name,$version) }
        return $name
    } catch {
        return [IO.Path]::GetFileNameWithoutExtension($HostRecord.HostExe)
    }
}

# A FrameBridge proxy: a known build, or any of our builds (also unreleased test builds that never made
# it into the list above): all of them carry the name of their log, cubase_dsreader.log (UTF-16).
# Rollback stays safe either way: only the state-bound, verified original engine is ever restored.
function Test-OurProxy([string]$Path, [string]$Hash) {
    if ($script:KnownProxyHashes -contains $Hash) { return $true }
    try {
        $bytes = [IO.File]::ReadAllBytes($Path)
        foreach ($offset in 0, 1) {
            if ([Text.Encoding]::Unicode.GetString($bytes, $offset, $bytes.Length - $offset).Contains('cubase_dsreader.log')) { return $true }
        }
    } catch { }
    return $false
}

function Test-HostEligible($HostRecord, $State, [string]$ForAction) {
    try {
        $hash = Get-FileSha256 $HostRecord.EnginePath
        $profile = Get-CompatibleEngine $HostRecord.EnginePath $HostRecord.HostExe
        if ($ForAction -eq 'Install') {
            if ($profile) { return $true }
            if (Test-OurProxy $HostRecord.EnginePath $hash) { return $null -ne (Find-ValidOriginal $HostRecord $State) }
            return $false
        }
        $binding = Get-BoundStateInstall $HostRecord $State $true
        if (-not $binding) { return $false }
        if ($profile) {
            if ($hash -eq $binding.OriginalHash) { return $true }
            # Beta 2: updated over FrameBridge - our backup of the previous original is still there.
            return (Test-Path -LiteralPath $HostRecord.BackupPath -PathType Leaf) -and
                   ((Get-FileSha256 $HostRecord.BackupPath) -eq $binding.OriginalHash)
        }
        if (Test-OurProxy $HostRecord.EnginePath $hash) { return $null -ne (Find-ValidOriginal $HostRecord $State) }
        return $false
    } catch {
        Write-Warn ("Not selectable: {0}: {1}" -f $HostRecord.HostPath,$_.Exception.Message)
        return $false
    }
}

function Request-ManualHosts {
    while ($true) {
        Write-Host ''
        Write-Info 'No compatible registered Cubase/Nuendo installation was found. Select its EXE or installation folder.'
        $shell = $null
        $selection = $null
        try {
            $shell = New-Object -ComObject Shell.Application
            # Standard Shell browser: new dialog + edit box + files and folders.
            $selection = $shell.BrowseForFolder(0, 'Select Cubase*.exe, Nuendo*.exe, or the installation folder', 0x4050, 0)
            if ($null -eq $selection) { return @() }
            $selectedPath = [string]$selection.Self.Path
        } finally {
            if ($selection) { try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($selection) } catch { } }
            if ($shell) { try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) } catch { } }
        }
        if (-not $selectedPath) { return @() }
        $list = New-Object 'Collections.Generic.List[object]'
        Find-HostsAtExplicitPath $selectedPath $list
        $array = New-Object object[] $list.Count
        $list.CopyTo($array)
        if ($array.Count -gt 0) { return $array }
        Write-Warn 'The selected item is not a Cubase/Nuendo executable or installation folder with Components\videoengine.dll.'
    }
}

function Select-HostsFromList($Hosts, [string]$ForAction) {
    # One candidate is taken without asking only when it is the only compatible installation
    # (or was named explicitly). If others were skipped as already current, ask - never install
    # on a remaining host the user did not pick.
    if ($Hosts.Count -eq 1 -and ($ManualPath -or $script:SkippedCurrent -eq 0)) {
        Write-Info ("Automatically selected: {0}" -f (Get-HostDisplayName $Hosts[0]))
        Write-Host ("    {0}" -f $Hosts[0].HostPath)
        return @($Hosts[0])
    }
    Write-Host ''
    Write-Info ("Compatible installations available for {0}:" -f $ForAction.ToLowerInvariant())
    for ($i = 0; $i -lt $Hosts.Count; $i++) {
        Write-Host ("  [{0}] {1}" -f ($i + 1),(Get-HostDisplayName $Hosts[$i]))
        Write-Host ("      {0}" -f $Hosts[$i].HostPath)
    }
    while ($true) {
        $answer = Read-Host 'Select number(s), ranges (1-3), A for all, or 0 to cancel'
        if (-not $answer -or $answer.Trim() -match '^(?i:0|C|CANCEL|Q|QUIT)$') { return @() }
        if ($answer.Trim() -match '^(?i:A|ALL)$') { return @($Hosts) }
        $indices = New-Object 'Collections.Generic.List[int]'
        $valid = $true
        foreach ($token in @($answer -split '[,;\s]+' | Where-Object { $_ })) {
            if ($token -match '^(\d+)-(\d+)$') {
                $first = [int]$matches[1]; $last = [int]$matches[2]
                if ($first -lt 1 -or $last -lt $first -or $last -gt $Hosts.Count) { $valid = $false; break }
                for ($n = $first; $n -le $last; $n++) { if (-not $indices.Contains($n - 1)) { $indices.Add($n - 1) } }
            } elseif ($token -match '^\d+$') {
                $n = [int]$token
                if ($n -lt 1 -or $n -gt $Hosts.Count) { $valid = $false; break }
                if (-not $indices.Contains($n - 1)) { $indices.Add($n - 1) }
            } else { $valid = $false; break }
        }
        if ($valid -and $indices.Count -gt 0) { return @($indices | ForEach-Object { $Hosts[$_] }) }
        Write-Warn 'Invalid selection; no files have been changed.'
    }
}

function Select-HostTargets($State, [string]$ForAction) {
    $script:SkippedCurrent = 0
    if ($ManualPath) {
        $found = @(Get-ExplicitHosts $ManualPath)
        if ($found.Count -eq 0) { throw "The explicit path contains no valid Cubase/Nuendo installation: $ManualPath" }
    } else {
        $found = @(Discover-Hosts $State $ForAction)
    }
    $eligible = @($found | Where-Object { Test-HostEligible $_ $State $ForAction })
    if ($ForAction -eq 'Install') {
        # Current = this package's proxy AND this package's FFmpeg payload; an older payload is updated.
        $alreadyCurrent = @($eligible | Where-Object { (Get-FileSha256 $_.EnginePath) -eq $script:ProxyHash -and (Test-FfmpegCurrent $_) })
        $script:SkippedCurrent = $alreadyCurrent.Count
        if ($alreadyCurrent.Count -gt 0) {
            foreach ($hostRecord in $alreadyCurrent) {
                Write-Ok ("Already installed (current): {0}" -f $hostRecord.HostPath)
            }
            $currentPaths = @($alreadyCurrent | ForEach-Object { $_.HostPath })
            $eligible = @($eligible | Where-Object { $currentPaths -notcontains $_.HostPath })
            $found = @($found | Where-Object { $currentPaths -notcontains $_.HostPath })
            if ($eligible.Count -eq 0) {
                if ($found.Count -gt 0) { Write-Warn ("Ignored unsupported or untracked installations: {0}" -f $found.Count) }
                $script:InstallAlreadyCurrent = $true
                return @()
            }
        }
    }
    if ($eligible.Count -eq 0 -and -not $ManualPath) {
        $found = @(Request-ManualHosts)
        if ($found.Count -eq 0) { return @() }
        $eligible = @($found | Where-Object { Test-HostEligible $_ $State $ForAction })
    }
    if ($eligible.Count -eq 0) { throw 'No safely compatible installation was selected. Nothing was changed.' }
    if ($found.Count -gt $eligible.Count) { Write-Warn ("Ignored unsupported or untracked installations: {0}" -f ($found.Count - $eligible.Count)) }
    return @(Select-HostsFromList $eligible $ForAction)
}

function Assert-HostsClosed($Hosts) {
    $running = @()
    foreach ($hostRecord in $Hosts) {
        $processName = [IO.Path]::GetFileNameWithoutExtension($hostRecord.HostExe)
        if (Get-Process -Name $processName -ErrorAction SilentlyContinue) { $running += $hostRecord.HostExe }
    }
    if ($running.Count -gt 0) { throw ('Close these applications first: ' + (($running | Select-Object -Unique) -join ', ')) }
}

function Get-BoundStateInstall($HostRecord, $State, [bool]$AllowMissing = $false) {
    $hostPath = [IO.Path]::GetFullPath($HostRecord.HostPath).TrimEnd('\')
    $matches = @($State.Installs | Where-Object {
        if (-not $_.HostPath) { return $false }
        try { return ([IO.Path]::GetFullPath([string]$_.HostPath).TrimEnd('\') -ieq $hostPath) } catch { return $false }
    })
    if ($matches.Count -eq 0 -and $AllowMissing) { return $null }
    if ($matches.Count -ne 1) { throw "No unique install-state binding for: $hostPath" }

    $record = $matches[0]
    $expectedHash = ([string]$record.OriginalHash).ToUpperInvariant()
    if ($expectedHash -notmatch '^[0-9A-F]{64}$') { throw "Invalid original SHA-256 in install state for: $hostPath" }

    if (($record.PSObject.Properties.Name -contains 'BackupPath') -and $record.BackupPath) {
        try { $boundBackup = [IO.Path]::GetFullPath([string]$record.BackupPath) } catch { throw "Invalid backup path in install state for: $hostPath" }
        $expectedBackup = [IO.Path]::GetFullPath($HostRecord.BackupPath)
        if ($boundBackup -ine $expectedBackup) { throw "Backup path is not bound to this installation: $hostPath" }
    }
    return [pscustomobject]@{ Record=$record; OriginalHash=$expectedHash }
}

function Find-ValidOriginal($HostRecord, $State) {
    $binding = Get-BoundStateInstall $HostRecord $State
    $candidates = @(
        $HostRecord.BackupPath,
        (Join-Path $HostRecord.HostPath 'Components\videoengine_orig.dll')
    )
    foreach ($candidate in $candidates) {
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        $candidateHash = Get-FileSha256 $candidate
        if ($candidateHash -ne $binding.OriginalHash) { throw "Original backup SHA-256 does not match install state: $candidate" }
        $profile = Get-CompatibleEngine $candidate $HostRecord.HostExe
        if (-not $profile) { throw "Original backup failed engine compatibility verification: $candidate" }
        return [pscustomobject]@{ Path=$candidate; Profile=$profile; Hash=$binding.OriginalHash }
    }
    return $null
}

function Install-Atomically([string]$Source, [string]$Destination, [string]$ExpectedHash) {
    $directory = Split-Path -Parent $Destination
    $temp = Join-Path $directory ('.dsreader-' + [guid]::NewGuid().ToString('N') + '.tmp')
    $swap = Join-Path $directory ('.dsreader-' + [guid]::NewGuid().ToString('N') + '.old')
    try {
        Copy-Item -LiteralPath $Source -Destination $temp -Force
        if ((Get-FileSha256 $temp) -ne $ExpectedHash) { throw 'Temporary copy hash mismatch.' }
        if (Test-Path -LiteralPath $Destination -PathType Leaf) {
            [IO.File]::Replace($temp, $Destination, $swap, $true)
        } else {
            Move-Item -LiteralPath $temp -Destination $Destination
        }
        if ((Get-FileSha256 $Destination) -ne $ExpectedHash) { throw 'Installed file hash mismatch.' }
        if (Test-Path -LiteralPath $swap) { Remove-Item -LiteralPath $swap -Force }
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
    }
}

# MXF: the host routes a dropped .mxf to the audio importer because MXFHandler registers an
# audio-file class for it. The MXF proxy hides that class, so MXF with video goes to the video
# importer. Installed only over a verified original; the original is kept in _dsreader.
function Get-MxfPaths($HostRecord) {
    return [pscustomobject]@{
        Handler=(Join-Path $HostRecord.HostPath 'Components\MXFHandler\mxfhandler.dll')
        Backup=(Join-Path $HostRecord.HostPath '_dsreader\mxfhandler_orig.dll')
    }
}

function Remove-EmptyBackupDirectory([string]$BackupPath) {
    $directory = Split-Path -Parent $BackupPath
    if ((Test-Path -LiteralPath $directory -PathType Container) -and -not (Get-ChildItem -LiteralPath $directory -Force | Select-Object -First 1)) { Remove-Item -LiteralPath $directory -Force }
}

function Install-Mxf($HostRecord, [string]$PackageMxf) {
    $paths = Get-MxfPaths $HostRecord
    if (-not (Test-Path -LiteralPath $paths.Handler -PathType Leaf)) { return }
    $current = Get-FileSha256 $paths.Handler
    if ($script:KnownMxfOriginals -contains $current) {
        if (Test-Path -LiteralPath $paths.Backup -PathType Leaf) {
            if ((Get-FileSha256 $paths.Backup) -ne $current) { throw ("MXF: conflicting backup, MXF handler left untouched: {0}" -f $paths.Backup) }
        } else {
            $directory = Split-Path -Parent $paths.Backup
            if (-not (Test-Path -LiteralPath $directory -PathType Container)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
            Copy-Item -LiteralPath $paths.Handler -Destination $paths.Backup
            if ((Get-FileSha256 $paths.Backup) -ne $current) { throw 'MXF handler backup verification failed.' }
        }
        Install-Atomically $PackageMxf $paths.Handler $script:MxfProxyHash
    } elseif ($script:KnownMxfProxyHashes -contains $current) {
        if (-not (Test-Path -LiteralPath $paths.Backup -PathType Leaf) -or ($script:KnownMxfOriginals -notcontains (Get-FileSha256 $paths.Backup))) {
            throw ("MXF: proxy active but no verified original backup: {0}" -f $paths.Backup)
        }
        if ($current -ne $script:MxfProxyHash) { Install-Atomically $PackageMxf $paths.Handler $script:MxfProxyHash }
    } else {
        throw ("MXF: unknown MXFHandler left untouched: {0}" -f $paths.Handler)
    }
    Write-Ok ("MXF with video imports as video (drag and drop): {0}" -f $HostRecord.HostPath)
}

function Get-AviPaths($HostRecord) {
    return [pscustomobject]@{
        Handler=(Join-Path $HostRecord.HostPath 'Components\avisupport.dll')
        Backup=(Join-Path $HostRecord.HostPath '_dsreader\avisupport_orig.dll')
    }
}

function Install-Avi($HostRecord, [string]$PackageAvi) {
    $paths = Get-AviPaths $HostRecord
    if (-not (Test-Path -LiteralPath $paths.Handler -PathType Leaf)) { return }
    $current = Get-FileSha256 $paths.Handler
    if ($script:KnownAviOriginals -contains $current) {
        if (Test-Path -LiteralPath $paths.Backup -PathType Leaf) {
            if ((Get-FileSha256 $paths.Backup) -ne $current) { throw ("AVI: conflicting backup, avisupport left untouched: {0}" -f $paths.Backup) }
        } else {
            $directory = Split-Path -Parent $paths.Backup
            if (-not (Test-Path -LiteralPath $directory -PathType Container)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
            Copy-Item -LiteralPath $paths.Handler -Destination $paths.Backup
            if ((Get-FileSha256 $paths.Backup) -ne $current) { throw 'AVI support backup verification failed.' }
        }
        Install-Atomically $PackageAvi $paths.Handler $script:AviProxyHash
    } elseif ($script:KnownAviProxyHashes -contains $current) {
        if (-not (Test-Path -LiteralPath $paths.Backup -PathType Leaf) -or ($script:KnownAviOriginals -notcontains (Get-FileSha256 $paths.Backup))) {
            throw ("AVI: proxy active but no verified original backup: {0}" -f $paths.Backup)
        }
        if ($current -ne $script:AviProxyHash) { Install-Atomically $PackageAvi $paths.Handler $script:AviProxyHash }
    } else {
        Write-Warn ("AVI: unknown avisupport.dll left untouched (AVI stays with Steinberg's reader): {0}" -f $paths.Handler)
        return
    }
    Write-Ok ("AVI opens through FrameBridge: {0}" -f $HostRecord.HostPath)
}

function Uninstall-Avi($HostRecord) {
    $paths = Get-AviPaths $HostRecord
    if (-not (Test-Path -LiteralPath $paths.Handler -PathType Leaf)) { return $true }
    $current = Get-FileSha256 $paths.Handler
    $backupHash = ''
    if (Test-Path -LiteralPath $paths.Backup -PathType Leaf) { $backupHash = Get-FileSha256 $paths.Backup }
    if ($script:KnownAviProxyHashes -contains $current) {
        if ($script:KnownAviOriginals -notcontains $backupHash) {
            Write-Warn ("AVI: no verified original avisupport backup; nothing changed: {0}" -f $paths.Backup)
            return $false
        }
        Install-Atomically $paths.Backup $paths.Handler $backupHash
        Remove-Item -LiteralPath $paths.Backup -Force
        Remove-EmptyBackupDirectory $paths.Backup
        Write-Ok ("AVI support restored: {0}" -f $HostRecord.HostPath)
        return $true
    }
    if (($script:KnownAviOriginals -contains $current) -and $backupHash -eq $current) {
        Remove-Item -LiteralPath $paths.Backup -Force
        Remove-EmptyBackupDirectory $paths.Backup
    }
    return $true
}

function Uninstall-Mxf($HostRecord) {
    $paths = Get-MxfPaths $HostRecord
    if (-not (Test-Path -LiteralPath $paths.Handler -PathType Leaf)) { return $true }
    $current = Get-FileSha256 $paths.Handler
    $backupHash = ''
    if (Test-Path -LiteralPath $paths.Backup -PathType Leaf) { $backupHash = Get-FileSha256 $paths.Backup }
    if ($script:KnownMxfProxyHashes -contains $current) {
        if ($script:KnownMxfOriginals -notcontains $backupHash) {
            Write-Warn ("MXF: no verified original MXF handler backup; nothing changed: {0}" -f $paths.Backup)
            return $false
        }
        Install-Atomically $paths.Backup $paths.Handler $backupHash
        Remove-Item -LiteralPath $paths.Backup -Force
        Remove-EmptyBackupDirectory $paths.Backup
        Write-Ok ("MXF handler restored: {0}" -f $HostRecord.HostPath)
        return $true
    }
    if (($script:KnownMxfOriginals -contains $current) -and $backupHash -eq $current) {
        Remove-Item -LiteralPath $paths.Backup -Force
        Remove-EmptyBackupDirectory $paths.Backup
    }
    return $true
}

function Upsert-StateInstall($State, $HostRecord, $Profile, [string]$OriginalHash) {
    if ($State.PSObject.Properties.Name -contains 'Schema') { $State.Schema = 3 } else { $State | Add-Member -NotePropertyName Schema -NotePropertyValue 3 }
    $kept = @($State.Installs | Where-Object { $_.HostPath -ine $HostRecord.HostPath })
    $kept += [pscustomobject]@{ HostPath=[IO.Path]::GetFullPath($HostRecord.HostPath).TrimEnd('\'); HostExe=$HostRecord.HostExe; BackupPath=[IO.Path]::GetFullPath($HostRecord.BackupPath); Profile=$Profile.Id; CompatibilityMode=$Profile.Mode; OriginalHash=$OriginalHash.ToUpperInvariant(); UpdatedUtc=[DateTime]::UtcNow.ToString('o') }
    $State.Installs = $kept
}

function Install-One($HostRecord, $State, [string]$PackageProxy, [string]$StateRoot, [string]$StatePath) {
    Assert-FfmpegInstallSafe $HostRecord
    $currentHash = Get-FileSha256 $HostRecord.EnginePath
    $currentProfile = Get-CompatibleEngine $HostRecord.EnginePath $HostRecord.HostExe
    $original = $null

    if ($currentProfile) {
        $backupDirectory = Split-Path -Parent $HostRecord.BackupPath
        if (-not (Test-Path -LiteralPath $backupDirectory -PathType Container)) { New-Item -ItemType Directory -Path $backupDirectory -Force | Out-Null }
        if (Test-Path -LiteralPath $HostRecord.BackupPath -PathType Leaf) {
            $backupProfile = Get-CompatibleEngine $HostRecord.BackupPath $HostRecord.HostExe
            $backupHash = Get-FileSha256 $HostRecord.BackupPath
            if ($backupProfile -and $backupHash -ne $currentHash) {
                # Beta 2: Cubase/Nuendo was updated over FrameBridge. The backup is the previous
                # original recorded in the install state and the host now runs a new compatible
                # original: that new original becomes the backup. Any other backup stays a conflict.
                $binding = Get-BoundStateInstall $HostRecord $State $true
                if ($binding -and $backupHash -eq $binding.OriginalHash) {
                    Copy-Item -LiteralPath $HostRecord.EnginePath -Destination $HostRecord.BackupPath -Force
                    Write-Info ("Host was updated over FrameBridge; backup moved to the new original: {0}" -f $HostRecord.HostPath)
                    $backupHash = Get-FileSha256 $HostRecord.BackupPath
                }
            }
            if (-not $backupProfile -or $backupHash -ne $currentHash) { throw "Conflicting or invalid backup: $($HostRecord.BackupPath)" }
        } else {
            Copy-Item -LiteralPath $HostRecord.EnginePath -Destination $HostRecord.BackupPath
        }
        if ((Get-FileSha256 $HostRecord.BackupPath) -ne $currentHash) { throw 'Original backup verification failed.' }
        $original = [pscustomobject]@{ Path=$HostRecord.BackupPath; Profile=$currentProfile; Hash=$currentHash }
    } elseif (Test-OurProxy $HostRecord.EnginePath $currentHash) {
        $original = Find-ValidOriginal $HostRecord $State
        if (-not $original) { throw 'A proxy is active, but no verified original engine backup was found. Roll back/repair this host first.' }
        if ($original.Path -ine $HostRecord.BackupPath) {
            $backupDirectory = Split-Path -Parent $HostRecord.BackupPath
            if (-not (Test-Path -LiteralPath $backupDirectory -PathType Container)) { New-Item -ItemType Directory -Path $backupDirectory -Force | Out-Null }
            Copy-Item -LiteralPath $original.Path -Destination $HostRecord.BackupPath -Force
            if ((Get-FileSha256 $HostRecord.BackupPath) -ne $original.Hash) { throw 'Backup migration verification failed.' }
            $original = [pscustomobject]@{ Path=$HostRecord.BackupPath; Profile=$original.Profile; Hash=$original.Hash }
        }
    } else {
        Write-Warn ("Unsupported/modified engine left untouched: {0}" -f $HostRecord.HostPath)
        return $false
    }

    # Commit and verify the recovery binding before the first payload mutation.
    # A forced termination after this point can always be recovered by UNINSTALL.
    Upsert-StateInstall $State $HostRecord $original.Profile $original.Hash
    Save-State $State $StateRoot $StatePath
    $durableState = Load-State $StatePath
    $durableBinding = Get-BoundStateInstall $HostRecord $durableState
    if ($durableBinding.OriginalHash -ne $original.Hash) { throw 'Durable install-state verification failed.' }

    if ($currentHash -ne $script:ProxyHash) { Install-Atomically $PackageProxy $HostRecord.EnginePath $script:ProxyHash }
    Install-Ffmpeg $HostRecord
    Install-LegacyHelpers $HostRecord
    # MXF/AVI proxies only hide Steinberg's class so the file reaches the (watermarked) demo engine.
    if (Test-Path -LiteralPath $script:PackageMxf) { Install-Mxf $HostRecord $script:PackageMxf }
    if (Test-Path -LiteralPath $script:PackageAvi) { Install-Avi $HostRecord $script:PackageAvi }
    Write-Ok ("Installed: {0} [{1}]" -f $HostRecord.HostPath,$original.Profile.Id)
    return $true
}

function Add-ExtensionMappings($State) {
    if ($SkipExtensionMappings) { return }
    $added = @($State.AddedExtensions)
    foreach ($extension in $script:Extensions) {
        $key = 'Registry::HKEY_CLASSES_ROOT\Media Type\Extensions\.' + $extension
        $existing = $null
        try { $existing = (Get-Item -LiteralPath $key -ErrorAction Stop).GetValue('Source Filter') } catch { }
        if (-not $existing) {
            try {
                if (-not (Test-Path -LiteralPath $key)) { New-Item -Path $key -Force | Out-Null }
                Set-ItemProperty -LiteralPath $key -Name 'Source Filter' -Type String -Value $script:LavSource
                if ($added -notcontains $extension) { $added += $extension }
            } catch {
                Write-Warn ("Could not add mapping for .{0}: {1}" -f $extension,$_.Exception.Message)
            }
        }
    }
    $State.AddedExtensions = @($added | Select-Object -Unique)
}

function Remove-ExtensionMappings($State) {
    if ($SkipExtensionMappings) { return }
    foreach ($extension in @($State.AddedExtensions)) {
        $key = 'Registry::HKEY_CLASSES_ROOT\Media Type\Extensions\.' + $extension
        try {
            $existing = (Get-Item -LiteralPath $key -ErrorAction Stop).GetValue('Source Filter')
            if ([string]$existing -eq $script:LavSource) { Remove-ItemProperty -LiteralPath $key -Name 'Source Filter' -ErrorAction Stop }
        } catch { Write-Warn ("Could not remove mapping for .{0}: {1}" -f $extension,$_.Exception.Message) }
    }
    $State.AddedExtensions = @()
}

function Uninstall-One($HostRecord, $State) {
    $currentHash = Get-FileSha256 $HostRecord.EnginePath
    $currentProfile = Get-CompatibleEngine $HostRecord.EnginePath $HostRecord.HostExe
    if (-not $currentProfile -and -not (Test-OurProxy $HostRecord.EnginePath $currentHash)) {
        Write-Warn ("Unknown engine left untouched (nothing changed): {0}" -f $HostRecord.HostPath)
        return $false
    }

    # Validate the state-bound original before changing MXF, FFmpeg or the engine.
    if ($currentProfile) {
        $binding = Get-BoundStateInstall $HostRecord $State $true
        if (-not $binding) {
            Write-Ok ("Already original; no tracked product files changed: {0}" -f $HostRecord.HostPath)
            return $true
        }
        if ($currentHash -ne $binding.OriginalHash) {
            # Beta 2: the host was updated over FrameBridge and already runs its new original.
            # Only our leftovers go: the backup of the previous original (exactly the recorded
            # SHA-256), FFmpeg and helpers. The new original engine is not touched.
            $leftover = (Test-Path -LiteralPath $HostRecord.BackupPath -PathType Leaf) -and
                        ((Get-FileSha256 $HostRecord.BackupPath) -eq $binding.OriginalHash)
            if (-not $leftover) {
                Write-Warn ("Current original SHA-256 does not match install state; nothing changed: {0}" -f $HostRecord.HostPath)
                return $false
            }
            if (-not (Uninstall-Mxf $HostRecord)) { return $false }
            if (-not (Uninstall-Avi $HostRecord)) { return $false }
            Uninstall-Ffmpeg $HostRecord
            Uninstall-LegacyHelpers $HostRecord
            Remove-Item -LiteralPath $HostRecord.BackupPath -Force
            Remove-EmptyBackupDirectory $HostRecord.BackupPath
            Write-Ok ("Host was updated over FrameBridge; leftovers removed, the new original kept: {0}" -f $HostRecord.HostPath)
            return $true
        }
        if (Test-Path -LiteralPath $HostRecord.BackupPath -PathType Leaf) {
            if ((Get-FileSha256 $HostRecord.BackupPath) -ne $binding.OriginalHash) {
                Write-Warn ("Backup SHA-256 does not match install state; nothing changed: {0}" -f $HostRecord.BackupPath)
                return $false
            }
        }
        if (-not (Uninstall-Mxf $HostRecord)) { return $false }
            if (-not (Uninstall-Avi $HostRecord)) { return $false }
        Uninstall-Ffmpeg $HostRecord
        Uninstall-LegacyHelpers $HostRecord
        if (Test-Path -LiteralPath $HostRecord.BackupPath -PathType Leaf) {
            Remove-Item -LiteralPath $HostRecord.BackupPath -Force
            Remove-EmptyBackupDirectory $HostRecord.BackupPath
        }
        Write-Ok ("Already original and state verified: {0}" -f $HostRecord.HostPath)
        return $true
    }

    $original = Find-ValidOriginal $HostRecord $State
    if (-not $original) { Write-Fail ("No state-bound original backup for: {0}" -f $HostRecord.HostPath); return $false }
    if (-not (Uninstall-Mxf $HostRecord)) { return $false }
            if (-not (Uninstall-Avi $HostRecord)) { return $false }
    Install-Atomically $original.Path $HostRecord.EnginePath $original.Hash
    if ((Get-FileSha256 $HostRecord.EnginePath) -ne $original.Hash) { throw 'Restored engine SHA-256 does not match install state.' }
    if (-not (Get-CompatibleEngine $HostRecord.EnginePath $HostRecord.HostExe)) { throw 'Restored engine failed compatibility verification.' }
    Uninstall-Ffmpeg $HostRecord
    Uninstall-LegacyHelpers $HostRecord
    if ((Test-Path -LiteralPath $HostRecord.BackupPath -PathType Leaf) -and (Get-FileSha256 $HostRecord.BackupPath) -eq $original.Hash) {
        Remove-Item -LiteralPath $HostRecord.BackupPath -Force
        Remove-EmptyBackupDirectory $HostRecord.BackupPath
    }
    Write-Ok ("Restored state-bound original: {0}" -f $HostRecord.HostPath)
    return $true
}

$packageRoot = Split-Path -Parent $PSScriptRoot
$packageProxy = Join-Path $PSScriptRoot 'videoengine.dll'   # _runtime\videoengine.dll
$script:PackageMxf = Join-Path $PSScriptRoot 'mxfhandler.dll'
$script:PackageAvi = Join-Path $PSScriptRoot 'avisupport.dll'
$script:PackageFfmpeg = Join-Path $PSScriptRoot 'ffmpeg'
$script:ProbePath = Join-Path $PSScriptRoot 'engine_compat_probe.exe'
$stateRoot = Get-StateRoot
$statePath = Join-Path $stateRoot 'install_state.json'

try {
    Write-Host ''
    Write-Host ("=== {0}: {1} ===" -f $script:ProductName,$Action) -ForegroundColor White
    Write-Host ''

    if ((Get-FileSha256 $script:ProbePath) -ne $script:ProbeHash) { throw 'The compatibility probe is missing or damaged.' }
    if ($Action -ne 'Status' -and -not $NoElevation -and -not (Test-IsAdministrator)) { Invoke-ElevatedSelf }
    $state = Load-State $statePath
    if ($Action -eq 'Status') {
        if ($ManualPath) { $hosts = @(Get-ExplicitHosts $ManualPath) } else { $hosts = @(Discover-Hosts $state $Action) }
        if ($hosts.Count -eq 0) { throw 'No registered or explicitly selected Cubase/Nuendo installation was found.' }
    } else {
        $hosts = @(Select-HostTargets $state $Action)
        if ($hosts.Count -eq 0) {
            if ($Action -eq 'Install' -and $script:InstallAlreadyCurrent) {
                Write-Ok 'FrameBridge is already current in every selected compatible installation. Nothing was changed.'
                exit 0
            }
            Write-Info ("{0} cancelled. Nothing was changed." -f $Action)
            exit 2
        }
    }

    if ($Action -eq 'Status') {
        foreach ($hostRecord in $hosts) {
            $hash = Get-FileSha256 $hostRecord.EnginePath
            $profile = Get-CompatibleEngine $hostRecord.EnginePath $hostRecord.HostExe
            if ($profile) { Write-Ok ("ORIGINAL {0} [{1}]" -f $hostRecord.HostPath,$profile.Id) }
            elseif ($hash -eq $script:ProxyHash) { Write-Ok ("CURRENT PROXY {0}" -f $hostRecord.HostPath) }
            elseif (Test-OurProxy $hostRecord.EnginePath $hash) { Write-Warn ("OLDER PROXY {0}" -f $hostRecord.HostPath) }
            else { Write-Warn ("UNKNOWN {0}" -f $hostRecord.HostPath) }
            $ffDir = Get-FfmpegDir $hostRecord
            if (Test-Path -LiteralPath $ffDir -PathType Container) {
                $bad = @($script:FfmpegFiles.Keys | Where-Object { (Get-FileSha256 (Join-Path $ffDir $_)) -ne $script:FfmpegFiles[$_] })
                if ($bad.Count -eq 0) { Write-Ok '    decoder runtime: FFmpeg (current)' } else { Write-Warn ('    decoder runtime: differs (' + ($bad -join ', ') + ')') }
            }
            $mxf = (Get-MxfPaths $hostRecord).Handler
            if (Test-Path -LiteralPath $mxf -PathType Leaf) {
                $mxfHash = Get-FileSha256 $mxf
                if ($mxfHash -eq $script:MxfProxyHash) { Write-Ok '    MXF: video import proxy (current)' }
                elseif ($script:KnownMxfProxyHashes -contains $mxfHash) { Write-Warn '    MXF: older video import proxy' }
                elseif ($script:KnownMxfOriginals -contains $mxfHash) { Write-Info '    MXF: original (MXF drops import as audio)' }
                else { Write-Warn '    MXF: unknown MXFHandler' }
            }
        }
        exit 0
    }

    Assert-HostsClosed $hosts
    if ($Action -eq 'Install') {
        if ((Get-FileSha256 $packageProxy) -ne $script:ProxyHash) { throw 'The packaged videoengine.dll is missing or damaged.' }
        if ((Test-Path -LiteralPath $script:PackageMxf) -and (Get-FileSha256 $script:PackageMxf) -ne $script:MxfProxyHash) { throw 'The packaged _runtime\mxfhandler.dll is damaged.' }
        if ((Test-Path -LiteralPath $script:PackageAvi) -and (Get-FileSha256 $script:PackageAvi) -ne $script:AviProxyHash) { throw 'The packaged _runtime\avisupport.dll is damaged.' }
        Test-FfmpegPayload
        $installed = 0
        $installFailed = 0
        foreach ($hostRecord in $hosts) {
            try {
                if (Install-One $hostRecord $state $packageProxy $stateRoot $statePath) { $installed++ } else { $installFailed++ }
            } catch {
                $installFailed++
                # Install-One durably records the verified original before any payload mutation.
                # A later failure remains recoverable; installFailed still forces overall exit 1.
                if (@($state.Installs | Where-Object { $_.HostPath -ieq $hostRecord.HostPath }).Count -gt 0) { $installed++ }
                Write-Fail ("{0}: {1}" -f $hostRecord.HostPath,$_.Exception.Message)
            }
        }
        if ($installed -eq 0) { throw 'Nothing was installed. All found engines were unsupported or could not be safely backed up.' }
        Save-State $state $stateRoot $statePath
        Write-Host ''
        if ($installFailed -ne 0) {
            Write-Fail ("Installation incomplete. Installed/updated hosts: {0}; failed or unsupported hosts: {1}." -f $installed,$installFailed)
            exit 1
        }
        Write-Ok ("Done. Installed/updated hosts: {0}. No native fallback is enabled." -f $installed)
        exit 0
    }

    $hostPaths = @($hosts | ForEach-Object { $_.HostPath })
    $remaining = @($state.Installs | Where-Object { $hostPaths -notcontains $_.HostPath })
    $rollbackFailed = 0
    foreach ($hostRecord in $hosts) {
        try {
            if (-not (Uninstall-One $hostRecord $state)) {
                $rollbackFailed++
                $old = @($state.Installs | Where-Object { $_.HostPath -ieq $hostRecord.HostPath })
                $remaining += $old
            }
        } catch {
            $rollbackFailed++
            Write-Fail ("{0}: {1}" -f $hostRecord.HostPath,$_.Exception.Message)
            $remaining += @($state.Installs | Where-Object { $_.HostPath -ieq $hostRecord.HostPath })
        }
    }
    $state.Installs = @($remaining)
    if ($state.Installs.Count -eq 0 -and $rollbackFailed -eq 0) { Remove-ExtensionMappings $state }
    Write-Host ''
    if ($state.Installs.Count -eq 0 -and $rollbackFailed -eq 0) {
        if (Test-Path -LiteralPath $statePath) { Remove-Item -LiteralPath $statePath -Force }
        if ((Test-Path -LiteralPath $stateRoot -PathType Container) -and -not (Get-ChildItem -LiteralPath $stateRoot -Force | Select-Object -First 1)) { Remove-Item -LiteralPath $stateRoot -Force }
        Write-Ok 'Rollback complete. Original engines restored.'
        exit 0
    }
    if ($state.Installs.Count -gt 0) { Save-State $state $stateRoot $statePath }
    if ($rollbackFailed -eq 0) {
        # The selected installation(s) are back to original; other Cubase/Nuendo copies stay installed.
        Write-Ok ("Rollback complete for the selected installation. Still installed in other copies: {0}" -f $state.Installs.Count)
        exit 0
    }
    Write-Warn ("Rollback incomplete; failed hosts: {0}; remaining tracked hosts: {1}" -f $rollbackFailed,$state.Installs.Count)
    exit 1
} catch {
    Write-Host ''
    Write-Fail $_.Exception.Message
    exit 1
}
